Vue.component('proj-preview', {
  props: ['title', 'due'],
  data: function () {
    return {
      seen: true,
    }
  },
  template: `
    <transition name="slide-fade">
    <div v-if="seen" id="proj-preview" class="borders glass">
    <section class="flexy">
      <h1 style="font-size: 20px">{{title}}</h1>
      <br />
    </section>
    <section class="flexy">
      <h1 style="font-size: 25px">Due in {{due}} days</h1>
    </section>
    <section class="flexy">
      <a href="">View Details ></a>
      <label for="checkbox">Completed ?</label>
      <input type="radio" name="" id="checkbox" v-model.lazy="seen" />
    </section>
  </div>
  </transition>
  `
})

new Vue({ el: '#projects' })
new Vue({ el: '#progress' })
new Vue({ el: '#to-do' })